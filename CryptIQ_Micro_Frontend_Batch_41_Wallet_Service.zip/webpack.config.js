
const ModuleFederationPlugin = require('webpack/lib/container/ModuleFederationPlugin');

module.exports = {
  mode: 'development',
  devServer: {
    port: 3002,
  },
  plugins: [
    new ModuleFederationPlugin({
      name: 'walletService',
      filename: 'remoteEntry.js',
      exposes: {
        './WalletComponent': './src/components/WalletComponent',
      },
      shared: ['react', 'react-dom'],
    }),
  ],
};
